package com.example.fastclicker;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private final Map<String, EditText> fields = new LinkedHashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView logView;
    private SharedPreferences prefs;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            logView.setText(ClickService.getLog());
            handler.postDelayed(this, 300);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Fast Clicker (root)");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Координаты X/Y: Настройки → Для разработчиков → «Расположение указателя», "
                + "коснитесь нужной точки и посмотрите значения. "
                + "Остановка: кнопка Громкость−, «Стоп» в шторке или авто-стоп.");
        info.setPadding(0, dp(8), 0, dp(8));
        root.addView(info);

        addField(root, "x", "X (пиксели)", "540", false);
        addField(root, "y", "Y (пиксели)", "1200", false);
        addField(root, "gap", "Пауза между кликами, мкс (1 мс = 1000 мкс, 0 = без паузы)", "2000", false);
        addField(root, "hold", "Удержание касания, мкс (0 = мгновенный тап)", "1000", false);
        addField(root, "fingers", "Пальцев одновременно (1–10)", "1", false);
        addField(root, "start", "Старт через, сек", "3", false);
        addField(root, "timeout", "Авто-стоп через, сек (0 = не останавливать)", "60", false);
        addField(root, "rot", "Поворот экрана: 0 / 90 / 180 / 270", "0", false);
        addField(root, "dev", "Устройство касания (пусто = авто), напр. /dev/input/event3", "", true);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(0, dp(16), 0, dp(8));

        Button start = new Button(this);
        start.setText("СТАРТ");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStart();
            }
        });
        Button stop = new Button(this);
        stop.setText("СТОП");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStop();
            }
        });
        buttons.addView(start, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        buttons.addView(stop, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(buttons);

        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        logView.setTextIsSelectable(true);
        root.addView(logView);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresh);
        saveFields();
        super.onPause();
    }

    private void addField(LinearLayout parent, String key, String label, String def, boolean text) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setPadding(0, dp(10), 0, 0);
        parent.addView(l);

        EditText e = new EditText(this);
        e.setInputType(text ? InputType.TYPE_CLASS_TEXT : InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setText(prefs.getString(key, def));
        parent.addView(e);
        fields.put(key, e);
    }

    private void saveFields() {
        SharedPreferences.Editor ed = prefs.edit();
        for (Map.Entry<String, EditText> en : fields.entrySet()) {
            ed.putString(en.getKey(), en.getValue().getText().toString().trim());
        }
        ed.apply();
    }

    private String val(String key) {
        return fields.get(key).getText().toString().trim();
    }

    private int num(String key, int def) {
        try {
            return Math.max(0, Integer.parseInt(val(key)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private void onStart() {
        saveFields();

        Point p = new Point();
        getWindowManager().getDefaultDisplay().getRealSize(p);
        int natW = Math.min(p.x, p.y); // естественная (портретная) ориентация панели
        int natH = Math.max(p.x, p.y);

        int rot = num("rot", 0);
        if (rot != 90 && rot != 180 && rot != 270) rot = 0;
        int fingers = Math.max(1, Math.min(10, num("fingers", 1)));
        String dev = val("dev").replaceAll("[^A-Za-z0-9/_.-]", "");

        StringBuilder sb = new StringBuilder();
        sb.append("natW=").append(natW);
        sb.append(" natH=").append(natH);
        sb.append(" rot=").append(rot);
        sb.append(" x=").append(num("x", 540));
        sb.append(" y=").append(num("y", 1200));
        sb.append(" gap=").append(num("gap", 2000));
        sb.append(" hold=").append(num("hold", 1000));
        sb.append(" fingers=").append(fingers);
        sb.append(" start=").append(num("start", 3));
        sb.append(" timeout=").append(num("timeout", 60));
        if (!dev.isEmpty()) sb.append(" dev=").append(dev);

        Intent i = new Intent(this, ClickService.class);
        i.setAction(ClickService.ACTION_START);
        i.putExtra("args", sb.toString());
        startForegroundService(i);
    }

    private void onStop() {
        Intent i = new Intent(this, ClickService.class);
        i.setAction(ClickService.ACTION_STOP);
        startService(i);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
