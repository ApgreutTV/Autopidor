package com.example.fastclicker;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.LockSupport;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Запускается от root через app_process (см. ClickService).
 * Пишет сырые события касания прямо в /dev/input/eventN тачскрина,
 * поэтому скорость ограничена только вашей паузой, а не Android-жестами.
 *
 * Остановка: строка "stop" (или конец) в stdin, кнопка Громкость-, авто-стоп по таймеру.
 */
public class RootClicker {

    static final int EV_SYN = 0, EV_KEY = 1, EV_ABS = 3;
    static final int SYN_REPORT = 0;
    static final int BTN_TOUCH = 0x14a;
    static final int ABS_MT_SLOT = 0x2f;
    static final int ABS_MT_TOUCH_MAJOR = 0x30;
    static final int ABS_MT_POSITION_X = 0x35;
    static final int ABS_MT_POSITION_Y = 0x36;
    static final int ABS_MT_TRACKING_ID = 0x39;
    static final int ABS_MT_PRESSURE = 0x3a;
    static final int KEY_VOLUMEDOWN = 114;

    static volatile boolean running = true;
    static volatile String stopReason = "";

    static void say(String s) {
        System.out.println(s);
    }

    static void stop(String reason) {
        if (running) {
            stopReason = reason;
            running = false;
        }
    }

    // ---------------------------------------------------------------- устройства

    static class Dev {
        String path = "";
        String name = "";
        boolean hasX, hasY, hasSlot, hasId, hasPressure, hasMajor, volDown;
        int minX, maxX, minY, maxY, maxSlot, maxPressure, maxMajor;

        long area() {
            return (long) (maxX - minX + 1) * (long) (maxY - minY + 1);
        }
    }

    static final Pattern RANGE = Pattern.compile("min\\s+(-?\\d+),\\s*max\\s+(-?\\d+)");
    static final Pattern PATH = Pattern.compile("(/dev/input/event\\d+)");
    static final Pattern NAME = Pattern.compile("name:\\s*\"(.*)\"");

    static List<Dev> parseGetevent(BufferedReader r) throws IOException {
        List<Dev> list = new ArrayList<>();
        Dev cur = null;
        String line;
        while ((line = r.readLine()) != null) {
            if (line.contains("add device")) {
                cur = new Dev();
                Matcher pm = PATH.matcher(line);
                if (pm.find()) cur.path = pm.group(1);
                list.add(cur);
                continue;
            }
            if (cur == null) continue;
            Matcher nm = NAME.matcher(line);
            if (nm.find()) {
                cur.name = nm.group(1);
                continue;
            }
            Matcher m = RANGE.matcher(line);
            boolean has = m.find();
            int lo = has ? Integer.parseInt(m.group(1)) : 0;
            int hi = has ? Integer.parseInt(m.group(2)) : 0;
            if (line.contains("ABS_MT_POSITION_X") && has) {
                cur.hasX = true;
                cur.minX = lo;
                cur.maxX = hi;
            } else if (line.contains("ABS_MT_POSITION_Y") && has) {
                cur.hasY = true;
                cur.minY = lo;
                cur.maxY = hi;
            } else if (line.contains("ABS_MT_SLOT") && has) {
                cur.hasSlot = true;
                cur.maxSlot = hi;
            } else if (line.contains("ABS_MT_TRACKING_ID")) {
                cur.hasId = true;
            } else if (line.contains("ABS_MT_PRESSURE") && has) {
                cur.hasPressure = true;
                cur.maxPressure = hi;
            } else if (line.contains("ABS_MT_TOUCH_MAJOR") && has) {
                cur.hasMajor = true;
                cur.maxMajor = hi;
            }
            if (line.contains("KEY_VOLUMEDOWN")) cur.volDown = true;
        }
        return list;
    }

    static List<Dev> scanDevices() throws Exception {
        String ge = System.getProperty("fc.getevent", "/system/bin/getevent");
        Process p = new ProcessBuilder(ge, "-pl").redirectErrorStream(true).start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        List<Dev> list = parseGetevent(r);
        p.waitFor();
        return list;
    }

    static Dev pickTouch(List<Dev> devs, String forced) {
        Dev best = null;
        for (Dev d : devs) {
            if (forced != null && !forced.isEmpty()) {
                if (d.path.equals(forced)) return d;
                continue;
            }
            if (d.hasX && d.hasY && d.hasId && d.hasSlot) {
                if (best == null || d.area() > best.area()) best = d;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- события

    /** Буфер из input_event (24 байта на 64-бит процессе, 16 на 32-бит). */
    static class Buf {
        final ByteBuffer bb;
        final int sz;

        Buf(int maxEvents, int sz) {
            this.sz = sz;
            this.bb = ByteBuffer.allocate(maxEvents * sz).order(ByteOrder.LITTLE_ENDIAN);
        }

        void ev(int type, int code, int value) {
            if (sz == 24) {
                bb.putLong(0);
                bb.putLong(0);
            } else {
                bb.putInt(0);
                bb.putInt(0);
            }
            bb.putShort((short) type);
            bb.putShort((short) code);
            bb.putInt(value);
        }

        byte[] bytes() {
            return Arrays.copyOf(bb.array(), bb.position());
        }
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Экранные пиксели (в текущей ориентации) -> сырые координаты тачскрина. */
    static int[] toRaw(Dev d, int natW, int natH, int rot, int dx, int dy) {
        double sx = (double) (d.maxX - d.minX + 1) / natW;
        double sy = (double) (d.maxY - d.minY + 1) / natH;
        double rx, ry;
        switch (rot) {
            case 90: // телефон повёрнут против часовой (верх слева)
                rx = d.maxX - dy * sx;
                ry = d.minY + dx * sy;
                break;
            case 180:
                rx = d.maxX - dx * sx;
                ry = d.maxY - dy * sy;
                break;
            case 270: // телефон повёрнут по часовой (верх справа)
                rx = d.minX + dy * sx;
                ry = d.maxY - dx * sy;
                break;
            default:
                rx = d.minX + dx * sx;
                ry = d.minY + dy * sy;
        }
        return new int[]{
                clamp((int) Math.round(rx), d.minX, d.maxX),
                clamp((int) Math.round(ry), d.minY, d.maxY)};
    }

    static byte[] buildDown(Dev d, int sz, int fingers, int rx, int ry) {
        Buf b = new Buf(fingers * 6 + 4, sz);
        for (int f = 0; f < fingers; f++) {
            b.ev(EV_ABS, ABS_MT_SLOT, f);
            b.ev(EV_ABS, ABS_MT_TRACKING_ID, f + 1);
            b.ev(EV_ABS, ABS_MT_POSITION_X, rx);
            b.ev(EV_ABS, ABS_MT_POSITION_Y, ry);
            if (d.hasPressure && d.maxPressure > 0) b.ev(EV_ABS, ABS_MT_PRESSURE, clamp(50, 1, d.maxPressure));
            if (d.hasMajor && d.maxMajor > 0) b.ev(EV_ABS, ABS_MT_TOUCH_MAJOR, clamp(10, 1, d.maxMajor));
        }
        b.ev(EV_KEY, BTN_TOUCH, 1);
        b.ev(EV_SYN, SYN_REPORT, 0);
        return b.bytes();
    }

    static byte[] buildUp(int sz, int fingers) {
        Buf b = new Buf(fingers * 2 + 4, sz);
        for (int f = 0; f < fingers; f++) {
            b.ev(EV_ABS, ABS_MT_SLOT, f);
            b.ev(EV_ABS, ABS_MT_TRACKING_ID, -1);
        }
        b.ev(EV_KEY, BTN_TOUCH, 0);
        b.ev(EV_SYN, SYN_REPORT, 0);
        return b.bytes();
    }

    static byte[] concat(byte[] a, byte[] b) {
        byte[] r = Arrays.copyOf(a, a.length + b.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    // ---------------------------------------------------------------- время

    /** Точная пауза: длинные куски спим, последние ~1 мс крутимся в цикле. */
    static void waitUs(long us) {
        if (us <= 0) return;
        long end = System.nanoTime() + us * 1000L;
        long rem;
        while ((rem = end - System.nanoTime()) > 0) {
            if (rem > 2_000_000L) LockSupport.parkNanos(rem - 1_000_000L);
        }
    }

    // ---------------------------------------------------------------- потоки-наблюдатели

    static void watchStdin() {
        final long t0 = System.nanoTime();
        Thread t = new Thread(() -> {
            String why = "stdin закрыт";
            try {
                byte[] buf = new byte[64];
                int n;
                while ((n = System.in.read(buf)) > 0) {
                    if (new String(buf, 0, n).contains("stop")) {
                        why = "команда «Стоп»";
                        break;
                    }
                }
            } catch (IOException ignored) {
            }
            if (!why.startsWith("команда") && System.nanoTime() - t0 < 1_500_000_000L) {
                // stdin «мёртвый» с самого начала: не считаем это командой стоп
                say("ВНИМАНИЕ: stdin не подключён, стоп только по Громкость−, таймеру или kill.");
                return;
            }
            stop(why);
        });
        t.setDaemon(true);
        t.start();
    }

    static void watchVolumeDown(final String path, final int sz) {
        Thread t = new Thread(() -> {
            int off = sz == 24 ? 16 : 8;
            byte[] b = new byte[sz];
            ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
            try (FileInputStream in = new FileInputStream(path)) {
                while (running) {
                    int got = 0;
                    while (got < sz) {
                        int n = in.read(b, got, sz - got);
                        if (n < 0) return;
                        got += n;
                    }
                    int type = bb.getShort(off) & 0xffff;
                    int code = bb.getShort(off + 2) & 0xffff;
                    int value = bb.getInt(off + 4);
                    if (type == EV_KEY && code == KEY_VOLUMEDOWN && value == 1) {
                        stop("кнопка Громкость−");
                        return;
                    }
                }
            } catch (IOException ignored) {
            }
        });
        t.setDaemon(true);
        t.start();
    }

    // ---------------------------------------------------------------- main

    static int num(Map<String, String> a, String k, int def) {
        try {
            return Integer.parseInt(a.get(k));
        } catch (Exception e) {
            return def;
        }
    }

    public static void main(String[] args) {
        try {
            run(args);
        } catch (Throwable t) {
            say("ОШИБКА: " + t);
            t.printStackTrace(System.out);
        }
        System.exit(0);
    }

    static void run(String[] args) throws Exception {
        Map<String, String> a = new HashMap<>();
        for (String s : args) {
            int i = s.indexOf('=');
            if (i > 0) a.put(s.substring(0, i), s.substring(i + 1));
        }
        int natW = Math.max(1, num(a, "natW", 1080));
        int natH = Math.max(1, num(a, "natH", 2400));
        int rot = num(a, "rot", 0);
        int x = num(a, "x", 540);
        int y = num(a, "y", 1200);
        long holdUs = Math.max(0, num(a, "hold", 1000));
        long gapUs = Math.max(0, num(a, "gap", 2000));
        int fingers = Math.max(1, num(a, "fingers", 1));
        int startSec = Math.max(0, num(a, "start", 3));
        int timeoutSec = Math.max(0, num(a, "timeout", 60));
        String forced = a.containsKey("dev") ? a.get("dev") : "";

        say("PID " + android.os.Process.myPid());
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        } catch (Throwable ignored) {
        }

        List<Dev> devs = scanDevices();
        Dev touch = pickTouch(devs, forced);
        if (touch == null) {
            say("ОШИБКА: тачскрин не найден. Устройства:");
            for (Dev d : devs) say("  " + d.path + " \"" + d.name + "\"");
            say("Впишите нужный /dev/input/eventN в поле «Устройство».");
            return;
        }
        if (!touch.hasSlot) {
            say("ОШИБКА: у " + touch.path + " нет ABS_MT_SLOT (протокол A не поддерживается)");
            return;
        }
        fingers = Math.min(fingers, touch.maxSlot + 1);

        int sz = android.os.Process.is64Bit() ? 24 : 16;
        int[] raw = toRaw(touch, natW, natH, rot, x, y);
        say("Тачскрин: " + touch.path + " \"" + touch.name + "\" raw " + touch.maxX + "x" + touch.maxY
                + ", слотов " + (touch.maxSlot + 1));
        say("Точка: экран (" + x + "," + y + ") rot=" + rot + " -> raw (" + raw[0] + "," + raw[1] + ")");
        say("Пальцев " + fingers + ", удержание " + holdUs + " мкс, пауза " + gapUs + " мкс");

        byte[] down = buildDown(touch, sz, fingers, raw[0], raw[1]);
        byte[] up = buildUp(sz, fingers);
        byte[] both = concat(down, up);

        watchStdin();
        int keyDevs = 0;
        for (Dev d : devs) {
            if (d.volDown && d != touch && !d.path.isEmpty()) {
                watchVolumeDown(d.path, sz);
                keyDevs++;
            }
        }
        say(keyDevs > 0 ? "Громкость− останавливает клики." : "Кнопка Громкость− не найдена, стоп только из приложения/по таймеру.");

        try (FileOutputStream out = new FileOutputStream(touch.path)) {
            out.write(buildUp(sz, touch.maxSlot + 1)); // сбросить «залипшие» пальцы от прошлых запусков

            for (int s = startSec; s > 0 && running; s--) {
                say("Старт через " + s + "…");
                for (int i = 0; i < 10 && running; i++) Thread.sleep(100);
            }
            if (running) say("КЛИКАЮ");

            long t0 = System.nanoTime();
            long lastPrint = t0;
            long total = 0, lastTotal = 0;
            try {
                while (running) {
                    if (holdUs == 0) {
                        out.write(both);
                    } else {
                        out.write(down);
                        waitUs(holdUs);
                        out.write(up);
                    }
                    total += fingers;
                    waitUs(gapUs);

                    long now = System.nanoTime();
                    if (now - lastPrint >= 1_000_000_000L) {
                        say("тапов/с: " + (total - lastTotal) + "  всего: " + total);
                        lastTotal = total;
                        lastPrint = now;
                    }
                    if (timeoutSec > 0 && now - t0 >= timeoutSec * 1_000_000_000L) {
                        stop("авто-стоп по таймеру (" + timeoutSec + " с)");
                    }
                }
            } finally {
                out.write(up); // обязательно отпустить палец
            }
            say("СТОП: " + stopReason + ". Всего тапов: " + total);
        }
    }
}
