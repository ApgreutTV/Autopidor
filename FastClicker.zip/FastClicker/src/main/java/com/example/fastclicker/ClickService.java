package com.example.fastclicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayDeque;

/**
 * Держит приложение «живым» (foreground-сервис) и запускает от root помощника RootClicker.
 * Если процесс приложения убьют — помощник тоже остановится (закроется его stdin).
 */
public class ClickService extends Service {

    public static final String ACTION_START = "com.example.fastclicker.START";
    public static final String ACTION_STOP = "com.example.fastclicker.STOP";
    private static final String CHANNEL = "clicker";

    // ---- журнал, который показывает MainActivity
    private static final ArrayDeque<String> LOG = new ArrayDeque<>();
    private static String rateLine = "";

    static synchronized void log(String s) {
        if (s.startsWith("тапов/с")) {
            rateLine = s;
            return;
        }
        LOG.addLast(s);
        while (LOG.size() > 60) LOG.removeFirst();
    }

    static synchronized void clearLog() {
        LOG.clear();
        rateLine = "";
    }

    static synchronized String getLog() {
        StringBuilder sb = new StringBuilder();
        for (String s : LOG) sb.append(s).append('\n');
        if (!rateLine.isEmpty()) sb.append(rateLine).append('\n');
        return sb.toString();
    }

    // ---- состояние помощника
    private Process proc;
    private OutputStream procIn;
    private volatile int helperPid = -1;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_START.equals(action)) {
            startForeground(1, buildNotification());
            boolean busy;
            synchronized (this) {
                busy = proc != null;
            }
            if (busy) {
                log("Уже запущено. Сначала нажмите «Стоп».");
            } else {
                startHelper(intent.getStringExtra("args"));
            }
        } else if (ACTION_STOP.equals(action)) {
            stopHelper();
        } else {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        OutputStream in;
        synchronized (this) {
            in = procIn;
        }
        if (in != null) {
            try {
                in.write("stop\n".getBytes());
                in.flush();
            } catch (IOException ignored) {
            }
        }
        super.onDestroy();
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Fast Clicker", NotificationManager.IMPORTANCE_LOW));

        Intent stop = new Intent(this, ClickService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Fast Clicker")
                .setContentText("Работает. Громкость− или «Стоп» остановит.")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Стоп", pi)
                .build();
    }

    private void startHelper(String args) {
        clearLog();
        helperPid = -1;
        final String cmd = "export CLASSPATH='" + getPackageCodePath() + "'; "
                + "exec /system/bin/app_process /system/bin com.example.fastclicker.RootClicker "
                + (args == null ? "" : args);
        log("Запускаю от root: " + (args == null ? "" : args));

        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean gotPid = false;
                try {
                    Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
                    synchronized (ClickService.this) {
                        proc = p;
                        procIn = p.getOutputStream();
                    }
                    BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (line.startsWith("PID ")) {
                            gotPid = true;
                            try {
                                helperPid = Integer.parseInt(line.substring(4).trim());
                            } catch (NumberFormatException ignored) {
                            }
                        }
                        log(line);
                    }
                    int code = p.waitFor();
                    log("Завершено (код " + code + ")");
                    if (!gotPid) {
                        log("Помощник не стартовал. Проверьте, что в KernelSU приложению Fast Clicker "
                                + "разрешён root (вкладка «Суперпользователь»), и что root активен после перезагрузки.");
                    }
                } catch (Exception e) {
                    log("Ошибка запуска: " + e);
                } finally {
                    synchronized (ClickService.this) {
                        proc = null;
                        procIn = null;
                    }
                    helperPid = -1;
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            stopForeground(true);
                            stopSelf();
                        }
                    });
                }
            }
        }).start();
    }

    /** Мягкая остановка командой «stop», через 1.2 с — принудительно kill. */
    private void stopHelper() {
        final OutputStream in;
        final int pid;
        synchronized (this) {
            in = procIn;
            pid = helperPid;
            if (proc == null) {
                stopSelf();
                return;
            }
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (in != null) {
                        in.write("stop\n".getBytes());
                        in.flush();
                    }
                } catch (IOException ignored) {
                }
                try {
                    Thread.sleep(1200);
                } catch (InterruptedException ignored) {
                }
                boolean alive;
                synchronized (ClickService.this) {
                    alive = proc != null;
                }
                if (alive && pid > 0) {
                    log("Принудительная остановка…");
                    try {
                        new ProcessBuilder("su", "-c", "kill -9 " + pid).start().waitFor();
                    } catch (Exception ignored) {
                    }
                }
            }
        }).start();
    }
}
